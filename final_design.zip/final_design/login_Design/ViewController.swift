//
//  ViewController.swift
//  animy
//
//  Created by m on 9/9/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet var main: UIView!
    @IBOutlet var view_social: UIButton!
    @IBOutlet var social_view: UIView!
    @IBOutlet var login: UIButton!
    @IBOutlet var register: UIButton!
    @IBOutlet var account: UIButton!
    @IBOutlet var GO_main: UIButton!
    @IBOutlet var user: UILabel!
    @IBOutlet var pass: UILabel!
    @IBOutlet var forget: UILabel!
     @IBOutlet var app_name: UILabel!
    @IBOutlet var mark_btn: UIButton!
    @IBOutlet var txt_f_n: UITextField!
    @IBOutlet var txt_f_p: UITextField!
    @IBOutlet var face: UIButton!
    @IBOutlet var twit: UIButton!
    @IBOutlet var google: UIButton!
    @IBOutlet var linked: UIButton!
    @IBOutlet var img_profile: UIImageView!
    @IBOutlet var hand_left: UIImageView!
    @IBOutlet var hand_right: UIImageView!
    @IBOutlet var copy_stack:UIStackView!
    @IBOutlet var social_stack:UIStackView!
    @IBOutlet var main_button_stack:UIStackView!
    let color = UIColor( red: CGFloat(93/255.0), green: CGFloat(45/255.0), blue: CGFloat(189/255.0), alpha: CGFloat(1.0))
    var stop_state = true
    let window = UIApplication.shared.keyWindow
    let screenSize = UIScreen.main.bounds
    //let topPadding = window?.safeAreaInsets.top
    //let bottomPadding = window?.safeAreaInsets.bottom







      /* override func viewDidLoad() {
        super.viewDidLoad()
        //===========================
        GO_main.isHidden = true
        hand_left.isHidden = true
        hand_right.isHidden = true
        img_profile.isHidden = true
        social_view.isHidden = true
        //===========================
        //print(self.GO_main.frame.origin.y)
        //print(self.GO_main.frame.origin.y)
        //print(self.face.frame.origin.y)
        //print(screenSize.width)
        // print(screenSize.height)
        //let width1 = container.frame.size.width
        //let hight1 = container.frame.size.height
       //=====================================

        
        
        
        
//=====================================
        txt_f_n.transform = CGAffineTransform(translationX: -450, y: 0)
        txt_f_p.transform = CGAffineTransform(translationX: -450, y: 0)
        user.transform = CGAffineTransform(scaleX: 0, y: 0)
        pass.transform = CGAffineTransform(scaleX: 0, y: 0)
        forget.transform = CGAffineTransform(scaleX: 0, y: 0)
        login.transform = CGAffineTransform(scaleX: 0, y: 0)
        register.transform = CGAffineTransform(translationX: -450, y: 0)
        view_social.transform = CGAffineTransform(translationX: 0, y: 450)
        account.transform = CGAffineTransform(translationX: 0, y: 450)
        social_view.transform = CGAffineTransform(translationX: 450, y: 0)
        face.alpha = 0
        twit.alpha = 0
        linked.alpha = 0
        google.alpha = 0
        UIView.animate(withDuration: 1, delay: 1, usingSpringWithDamping: 0.4, initialSpringVelocity: 0, options: [], animations:
            {
                self.txt_f_p.transform = CGAffineTransform.identity
                self.txt_f_n.transform = CGAffineTransform.identity
            }
            
            , completion: {
                (true) in
                UIView.animate(withDuration: 1, animations: {
                    self.user.transform = CGAffineTransform.identity
                    self.pass.transform = CGAffineTransform.identity
                    self.forget.transform = CGAffineTransform.identity
                }, completion:
                    {
                    (true) in
                        self.login.transform = CGAffineTransform(scaleX: 1.4, y: 0)
                        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0, options: [], animations:
                            {
                                self.login.transform = CGAffineTransform.identity
                        }, completion: {
                            
                            (true) in
                            UIView.animate(withDuration: 1, animations: {
                                
                                self.register.transform = CGAffineTransform.identity
                                
                                
                            }, completion:
 
                                {
                                 (true) in
                                    
                                    UIView.animate(withDuration: 1, delay: 1, usingSpringWithDamping: 0.4, initialSpringVelocity: 0, options: [], animations:
                                        {
                                            self.account.transform = CGAffineTransform.identity
                                            self.view_social.transform = CGAffineTransform.identity
                                    }
                                        
                                        , completion: nil)
                                }
                            
 
                            )
                }
                    )
                }) })
//==========================================
        
    }*/
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
    override func viewDidAppear(_ animated: Bool) {
        //===========================
        GO_main.isHidden = true
        hand_left.isHidden = true
        hand_right.isHidden = true
        img_profile.isHidden = true
        social_view.isHidden = true
        //===========================
        //print(self.GO_main.frame.origin.y)
        //print(self.GO_main.frame.origin.y)
        //print(self.face.frame.origin.y)
        //print(screenSize.width)
        // print(screenSize.height)
        //let width1 = container.frame.size.width
        //let hight1 = container.frame.size.height
        //**********************************
        
        
        
        
        
        //***********************************
        txt_f_n.transform = CGAffineTransform(translationX: -450, y: 0)
        txt_f_p.transform = CGAffineTransform(translationX: -450, y: 0)
        user.transform = CGAffineTransform(scaleX: 0, y: 0)
        pass.transform = CGAffineTransform(scaleX: 0, y: 0)
        forget.transform = CGAffineTransform(scaleX: 0, y: 0)
        login.transform = CGAffineTransform(scaleX: 0, y: 0)
        register.transform = CGAffineTransform(translationX: -450, y: 0)
        view_social.transform = CGAffineTransform(translationX: 0, y: 450)
        account.transform = CGAffineTransform(translationX: 0, y: 450)
        social_view.transform = CGAffineTransform(translationX: 450, y: 0)
        face.alpha = 0
        twit.alpha = 0
        linked.alpha = 0
        google.alpha = 0
        UIView.animate(withDuration: 1, delay: 1, usingSpringWithDamping: 0.4, initialSpringVelocity: 0, options: [], animations:
            {
                self.txt_f_p.transform = CGAffineTransform.identity
                self.txt_f_n.transform = CGAffineTransform.identity
        }
            
            , completion: {
                (true) in
                UIView.animate(withDuration: 1, animations: {
                    self.user.transform = CGAffineTransform.identity
                    self.pass.transform = CGAffineTransform.identity
                    self.forget.transform = CGAffineTransform.identity
                }, completion:
                    {
                        (true) in
                        self.login.transform = CGAffineTransform(scaleX: 1.4, y: 0)
                        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0, options: [], animations:
                            {
                                self.login.transform = CGAffineTransform.identity
                        }, completion: {
                            
                            (true) in
                            UIView.animate(withDuration: 1, animations: {
                                
                                self.register.transform = CGAffineTransform.identity
                                
                                
                            }, completion:
                                //**********************
                                {
                                    (true) in
                                    
                                    UIView.animate(withDuration: 1, delay: 1, usingSpringWithDamping: 0.4, initialSpringVelocity: 0, options: [], animations:
                                        {
                                            self.account.transform = CGAffineTransform.identity
                                            self.view_social.transform = CGAffineTransform.identity
                                    }
                                        
                                        , completion: nil)
                            }
                                
                                //*********************
                            )
                        }
                        )
                }) })
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 //==========================================
    func radian (_ angle: CGFloat) -> CGFloat
    {
      return (angle * .pi/180)
        
    }
  //==========================================
    @IBAction func login_action(_ sender: UIButton)
    {
        
        if(txt_f_n.text == "" || txt_f_p.text == "")
        {
            txt_f_n.attributedPlaceholder = NSAttributedString(string: "requierd email", attributes: [NSAttributedStringKey.foregroundColor:UIColor.gray])
            txt_f_p.attributedPlaceholder = NSAttributedString(string: "requierd pass", attributes: [NSAttributedStringKey.foregroundColor:UIColor.gray])
        }
       else
        {
            
            if (txt_f_n.text == "a" || txt_f_p.text == "a")
            {
                     login_success_animation()
            }
                else
                {
                    alert(title: "Not match", message: "user or pass not found", action: "ok")
                }
   
         }
 }
 
 //============================================================================
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txt_f_n.resignFirstResponder()
        txt_f_p.resignFirstResponder()
        return (true)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
//******************************************************************************
    @IBAction func social_action(_ sender: UIButton)
    {
        if (stop_state)
        {
            stop_state = false
            
            UIView.animate(withDuration: 1, animations: {
                
                self.view_social.frame.origin.y = self.social_view.frame.origin.y+6
                
                //self.view_social.transform = CGAffineTransform(translationX: 0, y:self.social_stack.frame.origin.y)
            }, completion: { (true) in
                UIView.animate(withDuration: 1, animations: {
                    self.view_social.transform = CGAffineTransform(rotationAngle: self.radian(90))
                    
                }, completion: {(true)in
                    UIView.animate(withDuration: 1, animations: {
                        self.social_view.isHidden = false
                        self.social_view.transform = CGAffineTransform.identity
                    }, completion: {(true)in
                        UIView.animate(withDuration: 0.5, animations: {
                             self.face.alpha = 1
                        }, completion: { (true) in
                            UIView.animate(withDuration: 0.5, animations: {
                                self.linked.alpha = 1
                                
                            }, completion: { (true) in
                                UIView.animate(withDuration: 0.5, animations: {
                                    self.google.alpha = 1
                                }, completion: { (true) in
                                    UIView.animate(withDuration: 0.5, animations: {
                                        self.twit.alpha = 1
                                    }, completion: { (true) in
                                        UIView.animate(withDuration: 0.5, animations: {
                                          self.view_social.transform = CGAffineTransform(rotationAngle: self.radian(180))
                                            
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        }

        else
        {
         stop_state = true
            UIView.animate(withDuration: 0.5, animations: {
                self.twit.alpha = 0
            }, completion: { (true) in
                
                UIView.animate(withDuration: 0.5, animations: {
                    self.google.alpha=0
                }, completion: { (true) in
                    UIView.animate(withDuration: 0.5, animations: {
                        self.linked.alpha = 0
                    }, completion: { (true) in
                        UIView.animate(withDuration: 0.5, animations: {
                            self.face.alpha = 0
                        }, completion: { (true) in
                            UIView.animate(withDuration: 1, animations: {
                                self.social_view.transform = CGAffineTransform(translationX: 450, y: 0)
                            }, completion: { (true) in
                                UIView.animate(withDuration: 0.5, animations: {
                                    self.view_social.frame.origin.y = (self.main_button_stack.frame.origin.y+self.main_button_stack.frame.size.height)-25
                                }, completion:{ (true) in
                                    UIView.animate(withDuration: 1, animations: {
                                       
                                       // self.view_social.isHidden = true
                                        
                                       // self.social_view.transform = CGAffineTransform(translationX: -8, y: 0)
                                        self.view_social.transform = CGAffineTransform(rotationAngle: self.radian(360))
                                    }, completion: nil)
                                  //self.view_social.transform = CGAffineTransform(rotationAngle: self.radian(180))
                                        
                                  
                                   
                                })
                            })
                        })
                    })
                })
            })
        }
    }
//*********************************************************
    
    
    func alert(title: String,message: String,action: String)
    {
        
        let myalert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let myaction = UIAlertAction(title: action, style: .cancel, handler: nil)
        myalert.addAction(myaction)
        self.present(myalert, animated: true, completion: nil)
        
        
    }
//*********************************************************
    
  override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
//*********************************************************
    
    func login_success_animation()
    {
        
       UIView.animate(withDuration: 2, animations:
        {
            self.txt_f_n.transform = CGAffineTransform(translationX: -450, y: 0)
            self.txt_f_p.transform = CGAffineTransform(translationX: -450, y: 0)
         
            
       }
        , completion: {(true) in
            UIView.animate(withDuration: 1, animations:
            {
               self.user.transform = CGAffineTransform(scaleX: 0, y: 0)
               self.pass.transform = CGAffineTransform(scaleX: 0, y: 0)
               self.forget.transform = CGAffineTransform(scaleX: 0, y: 0)
                    
            }
                , completion: { (true) in
                    self.login.transform = CGAffineTransform(scaleX: 1.4, y: 0)
                    UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0, options: [], animations:
                        {
                            self.login.transform = CGAffineTransform(scaleX: 0, y: 0)
                    }, completion: {
                        
                        (true) in
                        UIView.animate(withDuration: 1, animations: {
                           self.register.transform = CGAffineTransform(translationX: -450, y: 0)
                            
                        }, completion: { (true) in
                            
                            UIView.animate(withDuration: 1, animations: {
                               self.view_social.transform = CGAffineTransform(translationX: 0, y: 450)
                               self.account.transform = CGAffineTransform(translationX: 0, y: 450)
                                
                            }, completion: {
                                
                                (true)in
                               self.animation_successState()
                                
                            })
                        })
                            
                            
                            
                            
                            
                })
            })
        
        })
    }
 //*************************************************************************
    @IBAction func GO_Main(_ sender: UIButton)
    {
      performSegue(withIdentifier: "go1_2", sender: (Any).self)
    }
 //*************************************************************************
    
  func animation_successState()
  {
    
    self.copy_stack.isHidden = true
    img_profile.transform = CGAffineTransform(translationX: 0, y: -350)
    hand_left.transform = CGAffineTransform(translationX: -350, y: 0)
    hand_right.transform = CGAffineTransform(translationX: 764, y: 0)
    UIView.animate(withDuration: 2, animations:
        {
            self.app_name.transform = CGAffineTransform(translationX: 0, y: self.screenSize.height-(40+self.app_name.frame.size.height))
            print("gate")
    })
    UIView.animate(withDuration: 2, delay: 2, options: [], animations:
        {
            self.hand_left.isHidden = false
            self.hand_right.isHidden = false
            self.hand_left.transform = CGAffineTransform.identity
            self.hand_right.transform = CGAffineTransform.identity
            
    }) { (true) in
        
        UIView.animate(withDuration: 1, delay: 0.80, options: [.curveEaseOut], animations: {
            self.img_profile.isHidden = false
            self.img_profile.transform = CGAffineTransform.identity
        }, completion: nil)
        self.hand_left.setAnchorPoint(CGPoint(x: 0, y: 0.5))
        self.hand_right.setAnchorPoint(CGPoint(x: 1, y: 0.5))
        UIView.animate(withDuration: 0.3, delay:1.5, options: [], animations: {
            self.hand_left.transform = CGAffineTransform(rotationAngle: self.radian(20))
            self.hand_right.transform = CGAffineTransform(rotationAngle: self.radian(-20))
        }, completion: nil)
        UIView.animate(withDuration: 1, delay: 3, options: [], animations: {
            self.hand_left.transform = CGAffineTransform(rotationAngle: self.radian(55))
            self.hand_right.transform = CGAffineTransform(rotationAngle: self.radian(-55))
            self.img_profile.frame.origin.y = self.GO_main.frame.origin.y
        }, completion: {
            (true) in
            
            UIView.animate(withDuration: 3, animations: {
                self.img_profile.alpha = 0
            }, completion: { (true)in
                self.img_profile.isHidden = true
                self.GO_main.isHidden = false
                self.GO_main.alpha = 0
                self.GO_main.backgroundColor = self.color
                UIView.animate(withDuration: 1, delay: 0, options: [], animations: {
                    //self.GO_main.alpha = 0
                    // UIView.animate(withDuration: 0, animations: {
                    UIView.setAnimationRepeatCount(3)
                    self.GO_main.alpha = 1
                    // })
                }, completion: {
                    (true) in
                    UIView.animate(withDuration: 1, animations: {
                        self.hand_left.transform = CGAffineTransform(rotationAngle: self.radian(0))
                        self.hand_right.transform = CGAffineTransform(rotationAngle: self.radian(0))
                        
                    }, completion: { (true) in
                        UIView.animate(withDuration: 1, animations: {
                            self.hand_left.transform = CGAffineTransform(translationX: -350, y: 0)
                            self.hand_right.transform = CGAffineTransform(translationX: 764, y: 0)
                        })
                    })
                })
            })
        })
    }
 }
}



//----------------------------------------------------------
extension UIView {
    func setAnchorPoint(_ point: CGPoint) {
        var newPoint = CGPoint(x: bounds.size.width * point.x, y: bounds.size.height * point.y)
        var oldPoint = CGPoint(x: bounds.size.width * layer.anchorPoint.x, y: bounds.size.height * layer.anchorPoint.y);
        
        newPoint = newPoint.applying(transform)
        oldPoint = oldPoint.applying(transform)
        
        var position = layer.position
        
        position.x -= oldPoint.x
        position.x += newPoint.x
        
        position.y -= oldPoint.y
        position.y += newPoint.y
        
        layer.position = position
        layer.anchorPoint = point
    }
}
//------------------------------------------------------------





