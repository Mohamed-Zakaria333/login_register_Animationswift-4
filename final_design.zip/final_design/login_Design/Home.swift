//
//  ViewController.swift
//  animy
//
//  Created by m on 9/9/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class Home: UIViewController {
    /*@IBOutlet var main: UIView!
    @IBOutlet var container: UIView!
    @IBOutlet var circle: UIView!
    @IBOutlet var view_social: UIButton!
    @IBOutlet var login: UIButton!
    @IBOutlet var register: UIButton!
    @IBOutlet var account: UIButton!
    @IBOutlet var user: UILabel!
    @IBOutlet var pass: UILabel!
    @IBOutlet var forget: UILabel!
    @IBOutlet var ok_btn: UIButton!
    @IBOutlet var txt_f_n: UITextField!
    @IBOutlet var txt_f_p: UITextField!
    @IBOutlet var face: UIButton!
    @IBOutlet var twit: UIButton!
    @IBOutlet var google: UIButton!
    @IBOutlet var linked: UIButton!
    @IBOutlet var img_profile: UIImageView!
    @IBOutlet var hand1: UIImageView!
    @IBOutlet var hand2: UIImageView!*/
     //let color = UIColor( red: CGFloat(93/255.0), green: CGFloat(45/255.0), blue: CGFloat(189/255.0), alpha: CGFloat(1.0))
    
    override func viewDidLoad() {
        super.viewDidLoad()
//print(self.ma.frame.origin.y)
        
      /*  let screenSize = UIScreen.main.bounds
        let screenWidth = screenSize.width
        let screenHeight = screenSize.height
        
        print(screenWidth)
        print(screenHeight)
        print("=============2222===========")
        print(main.frame.size.width)
        print(main.frame.size.height)
        print("========================")
        //print(self.container.frame.origin.y)
        let width1 = container.frame.size.width
        let hight1 = container.frame.size.height
        print(width1)
        print(hight1)
        print(self.container.frame.origin.x)
        print(self.container.frame.origin.y)
      
        container.transform = CGAffineTransform(rotationAngle: radian (45))
       let width = container.frame.size.width
        let hight = container.frame.size.height
        print(width)
        print(hight)
        print(self.container.frame.origin.x)
        print(self.container.frame.origin.y)*/
        
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
      //  navigationController?.navigationBar.barTintColor = color

    }
   override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }


}

